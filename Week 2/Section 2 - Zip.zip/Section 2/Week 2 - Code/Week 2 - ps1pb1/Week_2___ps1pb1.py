#input
stocksymbol = input("Enter stock symbol: ")
numberofshare = float(input("Enter number of shares: "))
costpershare = float(input("Enter cost per share: "))

#process phase
amountinvested = numberofshare * costpershare

#output
print("Stock Symbol: ", stocksymbol)
print("Amount Invested: ", amountinvested)

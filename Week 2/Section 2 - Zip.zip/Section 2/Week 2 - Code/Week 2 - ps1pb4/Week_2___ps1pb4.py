#input
make = input("Enter car make: ")
model = input("Enter car model: ")
msrp = float(input("Enter car MSRP: ").replace(',', ''))
discount_percent = float(input("Enter discount percentage as a decimal: "))

#process phase
amount_off = msrp * discount_percent
discounted_price = msrp - amount_off

#output
print("Make:", make)
print("Model:", model)
print("MSRP: $", format(msrp, ',.2f'), sep='')
print("Discount Percentage:", format(discount_percent, '.0%'))
print("Amount Off: $", format(amount_off, ',.2f'), sep='')
print("Discounted Price: $", format(discounted_price, ',.2f'), sep='')

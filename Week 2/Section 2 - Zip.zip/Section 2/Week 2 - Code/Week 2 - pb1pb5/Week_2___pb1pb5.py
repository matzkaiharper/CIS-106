#input
radius = float(input("Enter the radius of the circle: "))

#process phase
area = 3.174 * (radius * radius)
perimeter = (2 * 3.174) * radius

#output
print ( "The area of the circle is: ", area)
print ( "The perimeter of the circle is: ", perimeter)
#input
lname = input("Enter student last name")
midterm = float(input("Enter midterm score"))
final = float(input("Enter final exam score"))

#process phase
total = midterm + final

#output
print("Student: ", lname)
print("Total points earned",total)

#input
total_amount = float(input("Enter the total amount received: "))

#process phase
share = total_amount / 3

#output
print ("Each person will receive: ", share)

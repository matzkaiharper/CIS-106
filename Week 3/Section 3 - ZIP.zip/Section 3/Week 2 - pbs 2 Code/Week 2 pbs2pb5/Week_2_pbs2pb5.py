#input
Lname = input("Enter your last name: ")
dependents = int(input("Enter number of dependents: "))
gross_income = float(input("Enter your gross income: "))

#process phase
adjusted_gross = gross_income - (dependents * 12000)
tax_rate = 0.20 if adjusted_gross > 50000 else 0.10
income_tax = adjusted_gross * tax_rate
if income_tax < 0:
    income_tax = 100.00

#output
print("Last Name:", Lname)
print("Number of Dependents:", dependents)
print("Gross Income: ", gross_income)
print("Adjusted Gross Income: ", adjusted_gross)
print("Income Tax: ", income_tax)

#input
item = input("Enter item (A or anything else for B): ")
quantity = float(input("Enter quantity: "))

#process phase
unit_price = 10.00 if item == "A" else 20.00
extended_price = unit_price * quantity

#output
print("Item: ", item)
print("Unit Price: ", unit_price)
print("Extended Price: ", extended_price)
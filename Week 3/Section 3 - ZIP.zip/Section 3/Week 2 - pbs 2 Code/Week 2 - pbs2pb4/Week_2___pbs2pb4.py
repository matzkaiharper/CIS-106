#input
appliance_name = input("Enter the appliance name: ")
price = float(input("Enter the price of the appliance: "))

#process phase
warranty_rate = 0.10 if price > 1000 else 0.05
warranty_cost = price * warranty_rate
total_cost = price + warranty_cost

#output
print("Appliance Name:", appliance_name)
print("Price: ", price)
print("Warranty Cost: ", warranty_cost)
print("Total Cost: ", total_cost)

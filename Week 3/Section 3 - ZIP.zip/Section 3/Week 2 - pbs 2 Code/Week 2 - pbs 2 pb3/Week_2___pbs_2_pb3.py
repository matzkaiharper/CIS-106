#input
num_books = int(input("Enter the number of books: "))
cost_per_book = float(input("Enter the cost per book: "))

#process phase
order_total = num_books * cost_per_book
shipping = 0.00 if order_total > 50.00 else 25.00

#output
print("Order total: ", order_total)
print("Shipping cost: ", shipping)

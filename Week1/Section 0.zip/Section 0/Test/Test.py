print("Hello World")
input("\n\nPress the Enter key to exit.")
#input
tickets = int(input("Enter number of concert tickets: "))

#process phase
if tickets >= 25:
    price = 50
elif tickets >= 10:
    price = 60
elif tickets >= 5:
    price = 70
else:
    price = 75

total = tickets * price

#output
print("Number of tickets: ", tickets)
print("Price per ticket: $", price)
print("Total cost: $", total)

#input
part = input("Enter part number: ")
quantity = int(input("Enter quantity: "))

#process phase
if part == "10" or part == "55":
    unit_cost = 1.00
elif part == "99":
    unit_cost = 2.00
elif part == "80" or part == "70":
    unit_cost = 3.00
else:
    unit_cost = 5.00
total_cost = quantity * unit_cost

#output
print("Part number:", part)
print("Unit Cost: $", unit_cost)
print("Total Cost: $", total_cost)

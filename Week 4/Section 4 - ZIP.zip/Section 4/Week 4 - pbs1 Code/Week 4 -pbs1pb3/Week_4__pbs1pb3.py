# input
principal = float(input("Enter principal amount: "))
years = int(input("Enter years to maturity: "))

# process phase
if principal > 100000 and years == 5:
    rate = 0.06
elif 50000 <= principal <= 100000 and years == 10:
    rate = 0.05
elif 50000 <= principal <= 100000 and years == 5:
    rate = 0.04

else:
    rate = 0.02

interest = principal * rate

#output
print("Principal: $", principal)
print("Interest Rate: ", rate * 100, "%", sep="")
print("First Year Interest: $", interest)

